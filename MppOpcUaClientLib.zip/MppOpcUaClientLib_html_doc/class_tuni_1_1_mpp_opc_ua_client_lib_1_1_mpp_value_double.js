var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double =
[
    [ "GetValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double.html#ab9402e38e0dd60e7bc8a03b8caef6c88", null ],
    [ "Value", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double.html#a3c7432268b3da1c98168187f130aa191", null ]
];