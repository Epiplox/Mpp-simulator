var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info =
[
    [ "StatusType", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129", [
      [ "Unknown", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "Disconnected", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129aef70e46fd3bbc21e3e1f0b6815e750c0", null ],
      [ "Connected", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129a2ec0d16e4ca169baedb9b2d50ec5c6d7", null ],
      [ "Connecting", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129ae321c53b354930ba96f0243e652df458", null ]
    ] ],
    [ "FullStatusString", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a895d0c636a4eec48c2bbe6cc7d4a4d8f", null ],
    [ "SimplifiedStatus", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a3dbad8a30e076fbe2df4019b25168bb2", null ]
];