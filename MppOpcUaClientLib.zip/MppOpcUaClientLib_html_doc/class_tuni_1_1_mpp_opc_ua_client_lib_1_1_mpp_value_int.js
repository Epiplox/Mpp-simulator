var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int =
[
    [ "GetValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int.html#a7ad1cc92958251ce530658b17d3fad83", null ],
    [ "Value", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int.html#a7f28856ef2c3e5acefa5a528a684fe7d", null ]
];