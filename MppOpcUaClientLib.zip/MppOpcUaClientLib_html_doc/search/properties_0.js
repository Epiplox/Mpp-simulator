var searchData=
[
  ['changeditems_0',['ChangedItems',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_process_item_changed_event_args.html#a72fded554e650fbe2247bec8e7a87568',1,'Tuni::MppOpcUaClientLib::ProcessItemChangedEventArgs']]],
  ['connectiontimeout_5fms_1',['ConnectionTimeout_ms',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#ae77718cff5ed436f7608b9b90f52c021',1,'Tuni::MppOpcUaClientLib::ConnectionParamsHolder']]]
];
