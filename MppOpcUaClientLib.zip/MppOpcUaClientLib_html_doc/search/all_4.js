var searchData=
[
  ['fullstatusstring_0',['FullStatusString',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a895d0c636a4eec48c2bbe6cc7d4a4d8f',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]]
];
