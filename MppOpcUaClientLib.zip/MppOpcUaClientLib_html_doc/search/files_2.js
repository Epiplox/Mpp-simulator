var searchData=
[
  ['processitemchangedeventargs_2ecs_0',['ProcessItemChangedEventArgs.cs',['../_process_item_changed_event_args_8cs.html',1,'']]]
];
