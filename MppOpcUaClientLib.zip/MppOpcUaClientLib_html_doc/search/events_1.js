var searchData=
[
  ['processitemschanged_0',['ProcessItemsChanged',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a9121ca9ceb04517880d221b92266d322',1,'Tuni::MppOpcUaClientLib::MppClient']]]
];
