var searchData=
[
  ['connected_0',['Connected',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129a2ec0d16e4ca169baedb9b2d50ec5c6d7',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]],
  ['connecting_1',['Connecting',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129ae321c53b354930ba96f0243e652df458',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]]
];
