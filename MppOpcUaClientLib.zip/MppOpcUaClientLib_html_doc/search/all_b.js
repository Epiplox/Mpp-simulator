var searchData=
[
  ['unknown_0',['Unknown',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129a88183b946cc5f0e8c96b2e66e1c74a7e',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]]
];
