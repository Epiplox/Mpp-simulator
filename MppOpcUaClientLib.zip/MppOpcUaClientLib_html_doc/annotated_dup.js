var annotated_dup =
[
    [ "Tuni", "namespace_tuni.html", [
      [ "MppOpcUaClientLib", "namespace_tuni_1_1_mpp_opc_ua_client_lib.html", [
        [ "ConnectionParamsHolder", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder" ],
        [ "ConnectionStatusEventArgs", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_event_args.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_event_args" ],
        [ "ConnectionStatusInfo", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info" ],
        [ "MppClient", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client" ],
        [ "MppValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value" ],
        [ "MppValueBool", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool" ],
        [ "MppValueDouble", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double" ],
        [ "MppValueInt", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int" ],
        [ "ProcessItemChangedEventArgs", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_process_item_changed_event_args.html", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_process_item_changed_event_args" ]
      ] ]
    ] ]
];