var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client =
[
    [ "MppClient", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#ae168d376b6575ea2b1659a42df92ccf3", null ],
    [ "AddToSubscription", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#ae69e25148ec925dbbd24c33d5f2223c6", null ],
    [ "ConnectionStatusEventHandler", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a7a700351bbd09f0fc5c0aeca5bf31ac5", null ],
    [ "Dispose", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a583ca9838549e1fdb2e44d72c1792a24", null ],
    [ "Init", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a1633873fe7f7c6a501bf51e18a11a635", null ],
    [ "ProcessItemsChangedEventHandler", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a9dee2808157b1963df4e7e4f9d7ee878", null ],
    [ "SetOnOffItem", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a7153dafecdce2bf676e04e18203a2d69", null ],
    [ "SetPumpControl", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a6c0e62b131e4d3b300b3bac345ec79af", null ],
    [ "SetValveOpening", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a4e983dd1bfda0c325012cd23022d8ff8", null ],
    [ "ConnectionStatus", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a087f35f46a8619d068a3744a9fafce2b", null ],
    [ "ProcessItemsChanged", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a9121ca9ceb04517880d221b92266d322", null ]
];