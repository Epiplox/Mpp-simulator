var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value =
[
    [ "ValueTypeType", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#ad29dbb76c40ffb02bdde3507d4404ad9", [
      [ "Bool", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#ad29dbb76c40ffb02bdde3507d4404ad9ac26f15e86e3de4c398a8273272aba034", null ],
      [ "Double", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#ad29dbb76c40ffb02bdde3507d4404ad9ad909d38d705ce75386dd86e611a82f5b", null ],
      [ "Int", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#ad29dbb76c40ffb02bdde3507d4404ad9a1686a6c336b71b36d77354cea19a8b52", null ]
    ] ],
    [ "MppValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#a220c1684930ed850f40cb636754965eb", null ],
    [ "GetValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#a9652d3872d6b076692edea29ed93cf52", null ],
    [ "ValueType", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#a4cc7045cbcbbc5529756c50d63ce6154", null ]
];