var hierarchy =
[
    [ "Tuni.MppOpcUaClientLib.ConnectionParamsHolder", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html", null ],
    [ "Tuni.MppOpcUaClientLib.ConnectionStatusInfo", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html", null ],
    [ "EventArgs", null, [
      [ "Tuni.MppOpcUaClientLib.ConnectionStatusEventArgs", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_event_args.html", null ],
      [ "Tuni.MppOpcUaClientLib.ProcessItemChangedEventArgs", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_process_item_changed_event_args.html", null ]
    ] ],
    [ "IDisposable", null, [
      [ "Tuni.MppOpcUaClientLib.MppClient", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html", null ]
    ] ],
    [ "Tuni.MppOpcUaClientLib.MppValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html", [
      [ "Tuni.MppOpcUaClientLib.MppValueBool", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool.html", null ],
      [ "Tuni.MppOpcUaClientLib.MppValueDouble", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double.html", null ],
      [ "Tuni.MppOpcUaClientLib.MppValueInt", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int.html", null ]
    ] ]
];