var searchData=
[
  ['getvalue_0',['GetValue',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value.html#a9652d3872d6b076692edea29ed93cf52',1,'Tuni.MppOpcUaClientLib.MppValue.GetValue()'],['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool.html#a76eabb254615121415cd33d06d24ce99',1,'Tuni.MppOpcUaClientLib.MppValueBool.GetValue()'],['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_double.html#ab9402e38e0dd60e7bc8a03b8caef6c88',1,'Tuni.MppOpcUaClientLib.MppValueDouble.GetValue()'],['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_int.html#a7ad1cc92958251ce530658b17d3fad83',1,'Tuni.MppOpcUaClientLib.MppValueInt.GetValue()']]]
];
