----- VERSIONS -----

MppOpcUaClientLib,  1.2.0.0
UnifiedAutomation.UaBase, 4.1.0.556 (Evaluation)
UnifiedAutomation.UaClient, 4.1.0.556 (Evaluation)

----- DOCUMENTATION -----

Doxygen generated HTML (Open with index.html)
Tuni.MppOpcUaClientLib.xml
https://documentation.unified-automation.com/uasdknet/4.1.0/html/namespaceUnifiedAutomation.html

----- USER GUIDE -----

Requires .NET 8.
Move the .dll files (3 pcs) to the project directory.
Add reference to the .dll files. (VS 2022 Project -> Add project reference)

Evaluation version shuts down after 1 hour and requires to be restarted.

----- Updating -----
See API Update Instructions