var searchData=
[
  ['serverurl_0',['ServerUrl',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#ad9e94b8e3851f7a938ba65bf26eec9dd',1,'Tuni::MppOpcUaClientLib::ConnectionParamsHolder']]],
  ['simplifiedstatus_1',['SimplifiedStatus',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a3dbad8a30e076fbe2df4019b25168bb2',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]],
  ['statusinfo_2',['StatusInfo',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_event_args.html#a97ede609115c2bd2952d78d4c6822f9e',1,'Tuni::MppOpcUaClientLib::ConnectionStatusEventArgs']]]
];
