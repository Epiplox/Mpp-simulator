var searchData=
[
  ['processitemschangedeventhandler_0',['ProcessItemsChangedEventHandler',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a9dee2808157b1963df4e7e4f9d7ee878',1,'Tuni::MppOpcUaClientLib::MppClient']]]
];
