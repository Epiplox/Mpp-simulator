var searchData=
[
  ['serverurl_0',['ServerUrl',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#ad9e94b8e3851f7a938ba65bf26eec9dd',1,'Tuni::MppOpcUaClientLib::ConnectionParamsHolder']]],
  ['setonoffitem_1',['SetOnOffItem',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a7153dafecdce2bf676e04e18203a2d69',1,'Tuni::MppOpcUaClientLib::MppClient']]],
  ['setpumpcontrol_2',['SetPumpControl',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a6c0e62b131e4d3b300b3bac345ec79af',1,'Tuni::MppOpcUaClientLib::MppClient']]],
  ['setvalveopening_3',['SetValveOpening',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_client.html#a4e983dd1bfda0c325012cd23022d8ff8',1,'Tuni::MppOpcUaClientLib::MppClient']]],
  ['simplifiedstatus_4',['SimplifiedStatus',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a3dbad8a30e076fbe2df4019b25168bb2',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]],
  ['statusinfo_5',['StatusInfo',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_event_args.html#a97ede609115c2bd2952d78d4c6822f9e',1,'Tuni::MppOpcUaClientLib::ConnectionStatusEventArgs']]],
  ['statustype_6',['StatusType',['../class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_status_info.html#a14ef428d6e9141e8bdbf2c1cff610129',1,'Tuni::MppOpcUaClientLib::ConnectionStatusInfo']]]
];
