var files_dup =
[
    [ "ConnectionParamsHolder.cs", "_connection_params_holder_8cs.html", "_connection_params_holder_8cs" ],
    [ "ConnectionStatusEventArgs.cs", "_connection_status_event_args_8cs.html", "_connection_status_event_args_8cs" ],
    [ "ConnectionStatusInfo.cs", "_connection_status_info_8cs.html", "_connection_status_info_8cs" ],
    [ "MppClient.cs", "_mpp_client_8cs.html", "_mpp_client_8cs" ],
    [ "MppValue.cs", "_mpp_value_8cs.html", "_mpp_value_8cs" ],
    [ "MppValueBool.cs", "_mpp_value_bool_8cs.html", "_mpp_value_bool_8cs" ],
    [ "MppValueDouble.cs", "_mpp_value_double_8cs.html", "_mpp_value_double_8cs" ],
    [ "MppValueInt.cs", "_mpp_value_int_8cs.html", "_mpp_value_int_8cs" ],
    [ "ProcessItemChangedEventArgs.cs", "_process_item_changed_event_args_8cs.html", "_process_item_changed_event_args_8cs" ]
];