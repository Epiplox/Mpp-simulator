var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder =
[
    [ "ConnectionParamsHolder", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#a2a19a68a139c656b9132510ad909afcb", null ],
    [ "ConnectionTimeout_ms", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#ae77718cff5ed436f7608b9b90f52c021", null ],
    [ "Plc1Namespace", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#a1f9a63041043cd4ddc7e8f504093a4ee", null ],
    [ "ServerUrl", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_connection_params_holder.html#ad9e94b8e3851f7a938ba65bf26eec9dd", null ]
];