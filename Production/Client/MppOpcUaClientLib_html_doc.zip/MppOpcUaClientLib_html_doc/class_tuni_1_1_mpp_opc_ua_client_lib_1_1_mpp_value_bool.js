var class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool =
[
    [ "GetValue", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool.html#a76eabb254615121415cd33d06d24ce99", null ],
    [ "Value", "class_tuni_1_1_mpp_opc_ua_client_lib_1_1_mpp_value_bool.html#a5e4332b068ffbe6a27ee4b302a8bace1", null ]
];