// Petri Kannisto, Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 5/2017
// Modified: 3/2025

/**
 * The application and server
 */

const express = require('express'),
    SSE = require('express-sse'),
    http = require('http'),
    path = require('path');

const UaServer = require("./UaServer");
const Equipment = require("./equipment");

// Creating the express server to port 8088.
var app = express();
app.set('port', process.env.PORT || 8088);
app.use(express.static(path.join(__dirname, 'public')));

http.createServer(app).listen(app.get('port'), function()
{
    console.log('Express server listening on port ' + app.get('port'));
});

// Creating Server Side Events in Express
// https://www.npmjs.com/package/express-sse

var sse = new SSE(); 
app.get('/stream', (req, res, next) => {
	res.flush = () => {};
	next();
}, sse.init);

// Instantiating OPC UA server and equipment handler.
var equipment = new Equipment();
equipment.initializeActuators();
var uaServer = new UaServer(equipment);

// Sending updates to GUI
setInterval(function()
{
	sse.send(equipment.serialize());
 
}, 500); // Every 500 ms

// Running simulation cycles
setInterval(function()
{
	equipment.runSimulation();
 
}, 100); // Every 100 ms

// Setting up a resource for simulation reset.
app.get('/reset', function(req, res)
{
	// Resetting simulation
	console.log("Got reset request, resetting simulation");
	equipment.reset();
	res.send("OK");
});
