// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

/**
 * Check all the possible routes for fluid in the system.
 * @param {Map} actuators Name of the actuators
 * @returns {Array} All the possbile routes
 */
function Routes(actuators)
{
    // Pairs of the route: [Start tank, Target tank, Pump]
    var allRoutes = [];

    /**
     * Checks the possible routes for fluid from tank T100.
     */
    this.T100FlowOutRoutes = function()
    {
        // Checks if flow out is possible
        if (actuators.get("V102") > 0 && 
            actuators.get("P100") > 0 && 
            actuators.get("P100_P200_PRESET") === true) {
            
            // Scenario: V403 -> T400
            if (actuators.get("V403") === true) {
                allRoutes.push(["T100", "T400", "P100"]);
            }

            // Scenario: V203 -> T200
            if (actuators.get("V203") === true) {
                allRoutes.push(["T100", "T200", "P100"]);
            }

            if (actuators.get("V304") === true) {
                // Scenario: V304 -> V103 -> T100
                if (actuators.get("V103") === true) {
                    allRoutes.push(["T100", "T100", "P100"]);
                }

                // Scenario: V304 -> V301 -> T300
                if (actuators.get("V301") === true) {
                    allRoutes.push(["T100", "T300", "P100"]);  
                }
            }
        }
    };

    /**
     * Checks the possible routes for fluid from tank T200.
     */
    this.T200FlowOutRoutes = function()
    {
        // Checks if flow out is possible
        if (actuators.get("V202") === true) {
            allRoutes.push(["T200", "T100", "Grav"]);
        }

        if (actuators.get("V201") === true && 
            actuators.get("P200") > 0 && 
            actuators.get("P100_P200_PRESET") === true) {

            // Scenario: V402 -> T400
            if (actuators.get("V402") === true) {
                allRoutes.push(["T200", "T400", "P200"]);
            }

            if (actuators.get("V303") === true) {
                // Scenario: V303 -> V301 -> T300
                if (actuators.get("V301") === true) {
                    allRoutes.push(["T200", "T300", "P200"]);
                }

                // Scenario: V303 -> V103 -> T100
                if (actuators.get("V103") === true) {
                    allRoutes.push(["T200", "T100", "P200"]);
                }
            }
        }
    };

    /**
     * Checks the possible routes for fluid from top of tank T300.
     */
    this.T300FlowOutTopRoutes = function()
    {
        // Scenario: V104 -> T100
        if (actuators.get("T300").getLevelPercent() == 1 && actuators.get("V104") > 0) {
            allRoutes.push(["T300T", "T100", "Vol"]);
        }

        // Scenario: V204 -> T200
        if (actuators.get("V204") === true) {
            allRoutes.push(["T300T", "T200", "Vol"]);
        }

        // Scenario: V401 -> T400
        if (actuators.get("V401") === true) {
            allRoutes.push(["T300T", "T400", "Vol"]);
        }
    };

    /**
     * Checks the possible routes for fluid from bottom of tank T300.
     */
    this.T300FlowOutBotRoutes = function()
    {
        if (actuators.get("V302") === true && 
        actuators.get("P200") > 0 && 
        actuators.get("P100_P200_PRESET") === true) {
            // Scenario: V402 -> T400
            if (actuators.get("V402") === true) {
                allRoutes.push(["T300B", "T400", "P200"]);
            }
 
            if (actuators.get("V303") === true) {
                // Scenario: V103 -> T100
                if (actuators.get("V103") === true) {
                    allRoutes.push(["T300B", "T100", "P200"]);
                }

                // Scenario: V301 -> T300
                if (actuators.get("V301") === true) {
                    allRoutes.push(["T300B", "T300", "P200"]);
                }
            }  
        }
    };

    /**
     * Checks the possible routes for fluid from tank T400.
     */
    this.T400FlowOutRoutes = function()
    {
        // Checks if flow out is possible
        if (actuators.get("V101") === true) {
            allRoutes.push(["T400", "T100", "Grav"]);
        }

        if (actuators.get("V404") === true && 
            actuators.get("P200") > 0 && 
            actuators.get("P100_P200_PRESET") === true) {

            // Scenario: V402 -> T400
            if (actuators.get("V402") === true) {
                allRoutes.push(["T400", "T400", "P200"]);
            }

            if (actuators.get("V303") === true) {
                // Scenario: V303 -> V103 -> T100
                if (actuators.get("V103") === true) {
                    allRoutes.push(["T400", "T100", "P200"]);
                }

                // Scenario: V303 -> V301 -> T300
                if (actuators.get("V301") === true) {
                    allRoutes.push(["T400", "T300", "P200"]);
                }
            }
        }
    };
    
    /**
     * Returns the list of all possible routes.
     * @returns {Array} List of all possible routes
     */
    this.returnRoutes = function() {
        return allRoutes;
    };

    this.T100FlowOutRoutes();
    this.T200FlowOutRoutes();
    this.T300FlowOutTopRoutes();
    this.T300FlowOutBotRoutes();
    this.T400FlowOutRoutes();
}

module.exports = Routes;
