// Petri Kannisto, Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 7/2017
// Modified: 3/2025

/**
 * Equipment handler
 */

const Tank = require("./Actuators/Tank");
const PressureTank = require("./Actuators/PressureTank");
const Simulation = require("./Simulation");

/**
 * Implements the equipment handler that contains all the actuators.
 */
class Equipment {
    constructor() {
        // Stores all the actuators
        this.actuators;
        this.simulation = new Simulation();
    }

    /**
     * Initializes the actuators.
     */
    initializeActuators() {
        this.actuators = new Map();

        // Tanks
        this.actuators.set("T100", new Tank("T100", 0.6, null, null, true));
        this.actuators.set("T200", new Tank("T200", 0.25, null, true, null));
        this.actuators.set("T300", new PressureTank("T300", 0.06));
        this.actuators.set("T400", new Tank("T400", 0.25, null, null, null));

        // On/off valves
        this.actuators.set("V101", false);
        this.actuators.set("V103", false);
        this.actuators.set("V201", false);
        this.actuators.set("V202", false);
        this.actuators.set("V203", false);
        this.actuators.set("V204", false);
        this.actuators.set("V301", false);
        this.actuators.set("V302", false);
        this.actuators.set("V303", false);
        this.actuators.set("V304", false);
        this.actuators.set("V401", false);
        this.actuators.set("V402", false);
        this.actuators.set("V403", false);
        this.actuators.set("V404", false);

        // Control valves
        this.actuators.set("V102", 0);
        this.actuators.set("V104", 0);

        // Heater
        this.actuators.set("E100", false);

        // Pumps and preset
        this.actuators.set("P100", 0);
        this.actuators.set("P200", 0);
        this.actuators.set("P100_P200_PRESET", false);
    };

    /**
     * Updates the actuator's value.
     * @param {string} name Name of the actuator
     * @param {Boolean, UInt16, Double} value Value of the actuator
     */
    updateActuator(name, value) {
        if (this.actuators.has(name)) {
            if (typeof(value) == typeof(this.actuators.get(name))) {
                this.actuators.set(name, value);

            }
            else {
                throw "Wrong value for " + name;
            }
        }
        else {
            throw "Unknown actuator " + name;
        }
    };

    /**
     * Get the value of the actuator.
     * @param {string} name Name of the actuator
     * @returns {Boolean, UInt16, Double} Value of the actuator
     */
    getActuator(name) {
        if (this.actuators.has(name)) {
            return this.actuators.get(name);

        }
        else {
            throw "Unknown actuator " + name;
        }
    };

    /**
     * Gets the indicators value from the Tank object.
     * @param {string} name Name of the indicator
     * @returns {UInt16, Double} The value of the indicator
     */
    getIndicator(name) {
        if (typeof(name) == "string") {
            if (name.startsWith("LI")) {
                var tankName = name.replace("LI", "T");
                var tank = this.actuators.get(tankName);
                return tank.level;

            } else if (name.startsWith("PI")) {
                return this.actuators.get("T300").getPressure();

            } else if (name.startsWith("TI")) {
                var tankName = name.replace("TI", "T");
                var tank = this.actuators.get(tankName);
                return tank.temperature;

            } else if (name.startsWith("FI100")) {
                return this.actuators.get("T100").flowOut;

            }
            else {
                throw "Unknown indicator " + name;
            }
        }
        else {
            throw "Unknown indicator " + name;
        }
    };

    /**
     * Gets the signal state from the Tank object.
     * @param {string} name Name of the sensor
     * @returns {Boolean} Signal state
     */
    getSignal(name) {
        switch (name) {
            case "LA_PLUS_100":
                return this.actuators.get("T100").levelAlarm;

            case "LS_MINUS_200":
                return this.actuators.get("T200").levelMin;

            case "LS_MINUS_300":
                return this.actuators.get("T300").levelMin;

            case "LS_PLUS_300":
                return this.actuators.get("T300").levelMax;

            default:
                throw "Unknown signal " + name;
        }
    };

    /**
     * Creates the JSON containing the necessary actuators for the frontend.
     * @returns {string} The Actuators in JSON format for the frontend
     */
    serialize() {
        var systemStates = "{" +

            // Tank levels
            this.#createSerializationItem("T100_LEVEL", this.actuators.get("T100").getLevelPercent()) +
            this.#createSerializationItem("T200_LEVEL", this.actuators.get("T200").getLevelPercent()) +
            this.#createSerializationItem("T300_LEVEL", this.actuators.get("T300").getLevelPercent()) +
            this.#createSerializationItem("T400_LEVEL", this.actuators.get("T400").getLevelPercent()) +

            // Control valves
            this.#createSerializationItem("V102", this.actuators.get("V102")) +
            this.#createSerializationItem("V104", this.actuators.get("V104")) +

            // On/off valves
            this.#createSerializationItem("V101", this.actuators.get("V101")) +
            this.#createSerializationItem("V103", this.actuators.get("V103")) +
            this.#createSerializationItem("V201", this.actuators.get("V201")) +
            this.#createSerializationItem("V202", this.actuators.get("V202")) +
            this.#createSerializationItem("V203", this.actuators.get("V203")) + 
            this.#createSerializationItem("V204", this.actuators.get("V204")) +
            this.#createSerializationItem("V301", this.actuators.get("V301")) +
            this.#createSerializationItem("V302", this.actuators.get("V302")) +
            this.#createSerializationItem("V303", this.actuators.get("V303")) +
            this.#createSerializationItem("V304", this.actuators.get("V304")) +
            this.#createSerializationItem("V401", this.actuators.get("V401")) +
            this.#createSerializationItem("V402", this.actuators.get("V402")) + 
            this.#createSerializationItem("V403", this.actuators.get("V403")) +
            this.#createSerializationItem("V404", this.actuators.get("V404")) +

            // Sensor values
            this.#createSerializationItem("LI100", Math.round(this.getIndicator("LI100"))) +
            this.#createSerializationItem("LI200", Math.round(this.getIndicator("LI200"))) +
            this.#createSerializationItem("LI400", Math.round(this.getIndicator("LI400"))) +
            this.#createSerializationItem("PI300", Math.round(this.getIndicator("PI300"))) +
            this.#createSerializationItem("FI100", this.getIndicator("FI100")) +
            this.#createSerializationItem("TI100", this.getIndicator("TI100")) +
            this.#createSerializationItem("TI300", this.getIndicator("TI300")) +

            // Alarms and signals
            this.#createSerializationItem("LA_PLUS_100", this.getSignal("LA_PLUS_100")) +
            this.#createSerializationItem("LS_MINUS_200", this.getSignal("LS_MINUS_200")) +
            this.#createSerializationItem("LS_MINUS_300", this.getSignal("LS_MINUS_300")) +
            this.#createSerializationItem("LS_PLUS_300", this.getSignal("LS_PLUS_300")) +

            // Pumps and preset
            this.#createSerializationItem("P100", this.actuators.get("P100")) +
            this.#createSerializationItem("P200", this.actuators.get("P200")) +

            // Heater
            this.#createSerializationItem("E100", this.actuators.get("E100"));

        systemStates = systemStates.substring(0, systemStates.length - 2) + "}";
        return systemStates;
    };

    /**
     * Resets the actuator to the starting values without
     * shutting the OPC UA connection.
     */
    reset() {
        this.initializeActuators();
    };

    /**
     * Runs a simulation cycle and updates the actuators.
     */
    runSimulation() {
        this.simulation = new Simulation();
        this.actuators = this.simulation.runSimulation(this.actuators);
    };

    /**
     * Creates the string needed for the frontend.
     * @param {string} name Name of the actuator
     * @param {Boolean, UInt16, Double} value Value of the actuator
     * @returns {string} Serializated string of the actuator
     */
    #createSerializationItem(name, value) {
        return '"' + name + '":"' + value + '"' + ", ";
    };
}

module.exports = Equipment;
