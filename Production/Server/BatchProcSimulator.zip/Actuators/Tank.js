// Petri Kannisto, Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 6/2017
// Modified: 3/2025

/**
 * Represents the basic tanks (T100, T200 and T400)
 */
class Tank {

    #volumeMax;
    #height;
    #heaterPower;
    #simulationCycle;
    #thermalCapacity;
    constructor(name, initialVolume, levelMax, levelMin, levelAlarm) {
        this.name = name;

        // Tank constants
        this.#volumeMax = 11; // Liter
        this.#height = 0.36; // Meter
        this.#heaterPower = 1000; // Watt
        this.#simulationCycle = 100; // Millisecond
        this.#thermalCapacity = 4190; // J/kg/C
        
        // Tank signals
        this.levelMax = levelMax; 
        this.levelMin = levelMin;
        this.levelAlarm = levelAlarm;

        // Tank states
        this.volume = initialVolume * this.#volumeMax; // Liter
        this.level = this.volume / this.#volumeMax * this.#height * 1000; // Millimeter, LI*00
        this.temperature = 20; // °C, TI*00
        this.flowIn = 0; // Liter/min
        this.flowOut = 0; // Liter/min
    }
    
    /**
     * Gets the fluid level as a percent.
     * @returns {number} The fluid level as a percent
     */
    getLevelPercent() {
        return this.volume / this.#volumeMax;
    };

    /**
     * Simulates the changes to the tank's volume during one cycle.
     * @param {number} flowIn The amount of fluid coming into the tank
     * @param {number} flowOut The amount of fluid going out of the tank
     */
    #simulateLiquid(flowIn, flowOut) {
        var netFlow = flowIn - flowOut; // May be negative
        this.flowIn = flowIn;
        this.flowOut = flowOut;

        // Calculate fluid amount
        if (Math.abs(netFlow) > 0.001) {
            var netFlowInPerSecond = netFlow / 60;
            var simulationCycleSeconds = this.#simulationCycle / 1000;
            var netFlowDuringCycle = netFlowInPerSecond * simulationCycleSeconds;
            this.volume = this.volume + netFlowDuringCycle;
        }
        
        // Cannot be negative
        if (this.volume < 0.001) {
            this.volume = 0;
        }
        
        // Cannot overflow
        if (this.volume > this.#volumeMax) {
            this.volume = this.#volumeMax;
        }

        // Update the level
        this.level = this.volume / this.#volumeMax * this.#height * 1000;

        // Level alarm for T100 (LA_PLUS_100)
        if (this.name == "T100") {
            if (this.getLevelPercent() < 0.95) {
                this.levelAlarm = true;

            } else {
                this.levelAlarm = false;
            }
        }

        // Level signal for T200 (LS_MINUS_200)
        if (this.name == "T200") {
            if (this.getLevelPercent() >= 0.20) {
                this.levelMin = true;

            } else {
                this.levelMin = false;
            }
        }
    };

    /**
     * Simulates the changes to the tank's temperature during one cycle.
     * @param {number} flowIn Amount of fluid flowing in
     * @param {number} flowTemp Temperature of fluid flowing in
     * @param {boolean} heaterState State of heater (E100)
     */
    #simulateTemperature(flowIn, flowTemp, heaterState) {
        // Temperature change with heating:
		// 
        //       P t
		// dT = -----
		//       c m
		//
		// P = 1000 W
		// t = simulation cycle length
		// c = 4190 J/kg/C
		// m ^ liquid volume in liters (water)
		
		// These are used to speed up heating simulation (for a faster client application development)
		var HEATING_MULTIPLIER = 10;
		var MIXING_MULTIPLIER = 10;
		var COOLING_MULTIPLIER = 25;

        if (this.name === "T100") {
            var dT = 0;
            
            if (heaterState === true) {
                // Heating is on
                dT = this.#heaterPower * (this.#simulationCycle / 1000) / this.#thermalCapacity / this.volume;
                dT = dT * HEATING_MULTIPLIER;
            }
            this.temperature += dT;
        }

        // Calculating temperature change due to flow in. Mass and volume are assumed proportional.
	    //      m1*T1 + m2*T2
		// T = ---------------
		//         m1 + m2
		
		if (flowIn >= 0.001) {
            var flowInSecond = flowIn / 60;
            var simulationCycleSeconds = this.#simulationCycle / 1000;
            var flowInDuringCycle = flowInSecond * simulationCycleSeconds;
            flowInDuringCycle = flowInDuringCycle * MIXING_MULTIPLIER;
            
            this.temperature =
                (this.volume * this.temperature + flowInDuringCycle * flowTemp) /
                (this.volume + flowInDuringCycle);
        }

        // Cooling is proportional to temperature difference.
		// T is temperature in, T0 is temperature out (20 C), a is constant.
		// 
		// dT = a(T-T0) = f(T)
		// 
		// 1) No change when no difference:
		//    f(0) = 0
		// 
		// 2) 30 C difference causes 1 C/min cooling speed:
		//    f(50) = 1/60
		// 
		// -> that makes a = 1/1800
		// 
		//          T - T0
		// -> dT = --------
		//           1800
		// (dT is per second!)
		
		// Calculating cooling effect
        var dT_cooling = -1 * (this.temperature - 20) / 1800 / 10;
        dT_cooling = dT_cooling * COOLING_MULTIPLIER;
        this.temperature += dT_cooling;

		// Limiting maximal temperature
		if (this.temperature > 80) {
            this.temperature = 80;
        }
    };

    /**
     * Function to update the values of the tank based on the flow of the system.
     * @param {number} flowIn The amount of fluid coming into the tank
     * @param {number} flowOut The amount of fluid going out of the tank
     * @param {number} flowTemp Temperature of fluid flowing in
     * @param {boolean} heaterState State of heater (E100)
     */
    runSimulation(flowIn, flowOut, flowTemp, heaterState) {
        // Simulate fluid volume and temperature separately
        this.#simulateLiquid(flowIn, flowOut);
        this.#simulateTemperature(flowIn, flowTemp, heaterState);
    };
}

module.exports = Tank;
