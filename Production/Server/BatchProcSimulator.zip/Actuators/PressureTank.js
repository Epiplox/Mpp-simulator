// Petri Kannisto, Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 6/2017
// Modified: 3/2025

/**
 * Represents the pressure tanks (T300)
 */
class PressureTank {

    #volumeMax;
    #simulationCycle;
    #pressureFull;
    #pressureNotFull;
    constructor(name, volume) {
        this.name = name;

        // Tank constants
        this.#volumeMax = 2; // Liter
        this.#simulationCycle = 100; // Millisecond
        this.#pressureFull = 0.29; // mPa
        this.#pressureNotFull = 0.12; // mPa

        // Tank signals
        this.levelMax = false;
        this.levelMin = true;

        // Tank states
        this.volume = volume * this.#volumeMax; // Liter
        this.pressure = 0; // mPa, PI*00
        this.temperature = 20; // °C, TI*00
        this.flowIn = 0; // Liter/min
        this.flowOut = 0; // Liter/min
    }

    /**
     * Gets the fluid level as a percent.
     * @returns {number} The fluid level as a percent
     */
    getLevelPercent() {
        return this.volume / this.#volumeMax;
    };

    /**
     * Gets the tank's pressure as hPa
     * @returns {number} Tank's pressure as hPa
     */
    getPressure() {
        return this.pressure * 1000;

    };

    /**
     * Simulates the changes to the tank's pressure during one cycle.
     * @param {boolean} pumpOn Check if a pump is on
     * @param {number} flowOut The amount of fluid going out of the tank
     * @param {boolean} pressureEscapes Checks if pressure can escape
     * @param {number} valve Position of the control valve
     * @param {number} yThrottle Throttle created by the control valve
     */
    #simulatePressure(pumpOn, flowOut, pressureEscapes, valve, yThrottle) {
        // Scenario 1: Pressure escapes due to open valves
        if (pressureEscapes == true) {
            this.pressure = 0;
            return; 
        }

        // Something is pumped into the tank
        if (pumpOn == true) {
            if (valve < 1) {
                if (this.volume < this.#volumeMax) {
                    // Scenario 2: some pressure due to pumping into a non-full tank with full throttling
                    this.pressure = this.#pressureNotFull;
                    return;

                } else {
                    // Scenario 3: full pressure due to pumping into a full tank with full throttling
                    this.pressure += 0.05;
                    if (this.pressure > this.#pressureFull) {
                        this.pressure = this.#pressureFull;

                    }
                    return;
                }

            } else {
                // Scenario 4: there is (possibly throttled) flow through the pressure tank
                // pd = y * Q
                this.pressure = yThrottle * flowOut;
                return;
            }

        } else {
            if (valve < 1) {
                // Scenario 5: the existing pressure persists due to closed valves although no pumping
                return;

            } else {
                // Scenario 6: pressure escapes due to open throttling valve and no flow in
                this.pressure = 0;
                return;
            }
        } 
    };

    /**
     * Simulates the changes to the tank's volume during one cycle.
     * @param {number} flowIn The amount of fluid coming into the tank
     * @param {number} flowOut The amount of fluid going out of the tank
     */
    #simulateLiquid(flowIn, flowOut) {
        var netFlow = flowIn - flowOut; // May be negative
        this.flowIn = flowIn;
        this.flowOut = flowOut;

        // Calculate fluid amount
        if (Math.abs(netFlow) > 0.001) {
            var netFlowInPerSecond = netFlow / 60;
            var simulationCycleSeconds = this.#simulationCycle / 1000;
            var netFlowDuringCycle = netFlowInPerSecond * simulationCycleSeconds;
            this.volume = this.volume + netFlowDuringCycle;
        }
        
        // Cannot be negative
        if (this.volume < 0.001) {
            this.volume = 0;
        }
        
        // Cannot overflow
        if (this.volume > this.#volumeMax) {
            this.volume = this.#volumeMax;
        }

        // Level signal for T300 (LS_PLUS_300)
        if (this.getLevelPercent() >= 0.95) {
            this.levelMax = true;

        } else {
            this.levelMax = false;
        }

        // Level signal for T300 (LS_MINUS_300)
        if (this.getLevelPercent() >= 0.05) {
            this.levelMin = true;

        } else {
            this.levelMin = false;
        }
    };

    /**
     * Simulates the changes to the tank's temperature during one cycle.
     * @param {number} flowIn Amount of fluid flowing in
     * @param {number} flowTemp Temperature of fluid flowing in
     */
    #simulateTemperature(flowIn, flowTemp) {
        // These are used to speed up heating simulation (for a faster client application development)
		var MIXING_MULTIPLIER = 10;
		var COOLING_MULTIPLIER = 25;

        // Calculating temperature change due to flow in. Mass and volume are assumed proportional.
        //      m1*T1 + m2*T2
        // T = ---------------
        //         m1 + m2
        if (flowIn >= 0.001) {
            var flowInSecond = flowIn / 60;
            var simulationCycleSeconds = this.#simulationCycle / 1000;
            var flowInDuringCycle = flowInSecond * simulationCycleSeconds;
            flowInDuringCycle = flowInDuringCycle * MIXING_MULTIPLIER;
            
            this.temperature =
                (this.volume * this.temperature + flowInDuringCycle * flowTemp) /
                (this.volume + flowInDuringCycle);
        }

        // Cooling is proportional to temperature difference.
        // T is temperature in, T0 is temperature out (20 C), a is constant.
        // 
        // dT = a(T-T0) = f(T)
        // 
        // 1) No change when no difference:
        //    f(0) = 0
        // 
        // 2) 30 C difference causes 1 C/min cooling speed:
        //    f(50) = 1/60
        // 
        // -> that makes a = 1/1800
        // 
        //          T - T0
        // -> dT = --------
        //           1800
        // (dT is per second!)
        
        // Calculating cooling effect
        var dT_cooling = -1 * (this.temperature - 20) / 1800 / 10;
        dT_cooling = dT_cooling * COOLING_MULTIPLIER;
        this.temperature += dT_cooling;

        // Limiting maximal temperature
        if (this.temperature > 80) {
            this.temperature = 80;
        }
    };

    /**
     * Function to update the values of the pressure tank based on the flow of the system.
     * @param {boolean} pumpOn Check if a pump is on
     * @param {number} flowIn The amount of fluid coming into the tank
     * @param {number} flowOut The amount of fluid going out of the tank 
     * @param {number} flowTemp Temperature of fluid flowing in
     * @param {boolean} pressureEscapes Checks if pressure can escape
     * @param {number} valve Position of the control valve
     * @param {number} yThrottle Throttle created by the control valve
     */
    runSimulation(pumpOn, flowIn, flowOut, flowTemp, pressureEscapes, valve, yThrottle) {
        // Simulate pressure, fluid volume and temperature separately
        this.#simulatePressure(pumpOn, flowOut, pressureEscapes, valve, yThrottle);
        this.#simulateLiquid(flowIn, flowOut);
        this.#simulateTemperature(flowIn, flowTemp);
    };
}

module.exports = PressureTank;
