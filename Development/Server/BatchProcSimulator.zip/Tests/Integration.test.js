// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const Equipment = require("../equipment");

describe("Integration tests IT:01", () => {

    test("Integration test, normal flow with pump, some pressure", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V201", true);
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V303", true);
        equipment.actuators.set("V301", true);
        
        // Run 100 cycles
        for (let i = 0; i < 100; i++) {
            equipment.runSimulation();
        }
        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.6\", \"T200_LEVEL\":\"0.189393939393938\", \"T300_LEVEL\":\"0.39333333333333387\", \"T400_LEVEL\":\"0.25\", \"V102\":\"0\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"true\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"true\", \"V302\":\"false\", \"V303\":\"true\", \"V304\":\"false\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"216\", \"LI200\":\"68\", \"LI400\":\"90\", \"PI300\":\"120\", \"FI100\":\"0\", \"TI100\":\"20\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"false\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"0\", \"P200\":\"100\", \"E100\":\"false\"}");
    });

    test("Integration test, normal flow with pump, no pressure", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 95);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("E100", true);
        equipment.actuators.set("V204", true);
        
        // Run 100 cycles
        for (let i = 0; i < 100; i++) {
            equipment.runSimulation();
        }
        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.5424242424242447\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"0.3766666666666665\", \"T400_LEVEL\":\"0.25\", \"V102\":\"95\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"true\", \"V301\":\"true\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"true\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"195\", \"LI200\":\"90\", \"LI400\":\"90\", \"PI300\":\"0\", \"FI100\":\"3.8\", \"TI100\":\"23.552695058929768\", \"TI300\":\"23.09197761991181\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"100\", \"P200\":\"0\", \"E100\":\"true\"}");
    });

    test("Integration test, normal flow through T300 with pump, no pressure", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 95);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("E100", true);
        equipment.actuators.set("V204", true);
        
        // Run 600 cycles
        for (let i = 0; i < 600; i++) {
            equipment.runSimulation();
        }

        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.2545454545454607\", \"T200_LEVEL\":\"0.4244545454545465\", \"T300_LEVEL\":\"1\", \"T400_LEVEL\":\"0.25\", \"V102\":\"95\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"true\", \"V301\":\"true\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"true\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"92\", \"LI200\":\"153\", \"LI400\":\"90\", \"PI300\":\"0\", \"FI100\":\"3.8\", \"TI100\":\"43.225902951919956\", \"TI300\":\"40.72981847845519\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"true\", \"P100\":\"100\", \"P200\":\"0\", \"E100\":\"true\"}");
    });

    test("Integration test, normal flow with pump with empty source tank using a new valve", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 100);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V403", true);
        
        // Run 1000 cycles
        for (let i = 0; i < 1000; i++) {
            equipment.runSimulation();
        }

        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"0.06\", \"T400_LEVEL\":\"0.8499999999999975\", \"V102\":\"100\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"false\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"false\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"true\", \"V404\":\"false\", \"LI100\":\"0\", \"LI200\":\"90\", \"LI400\":\"306\", \"PI300\":\"120\", \"FI100\":\"0\", \"TI100\":\"20\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"100\", \"P200\":\"0\", \"E100\":\"false\"}");
    });

    test("Integration test, controlling the pressure and temperature of the T300 using P100", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 100);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("E100", true);
        equipment.actuators.set("V104", 40);
        
        // Run 600 cycles
        for (let i = 0; i < 600; i++) {
            equipment.runSimulation();
        }

        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.42848484848484447\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"1\", \"T400_LEVEL\":\"0.25\", \"V102\":\"100\", \"V104\":\"40\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"true\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"true\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"154\", \"LI200\":\"90\", \"LI400\":\"90\", \"PI300\":\"185\", \"FI100\":\"1.5384615384615383\", \"TI100\":\"36.03932914096104\", \"TI300\":\"33.45380334128703\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"true\", \"P100\":\"100\", \"P200\":\"0\", \"E100\":\"true\"}");
    });

    test("Integration test, flow using gravity", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("V202", true);
        
        // Run 200 cycles
        for (let i = 0; i < 200; i++) {
            equipment.runSimulation();
        }

        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.7503182954238885\", \"T200_LEVEL\":\"0.0996817045761118\", \"T300_LEVEL\":\"0.06\", \"T400_LEVEL\":\"0.25\", \"V102\":\"0\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"true\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"false\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"false\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"270\", \"LI200\":\"36\", \"LI400\":\"90\", \"PI300\":\"0\", \"FI100\":\"0\", \"TI100\":\"20.000000000000007\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"false\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"0\", \"P200\":\"0\", \"E100\":\"false\"}");
    });

    test("Integration test, nothing happens", () => {
        var equipment = new Equipment();
        equipment.initializeActuators();
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        
        // Run 100 cycles
        for (let i = 0; i < 100; i++) {
            equipment.runSimulation();
        }

        // This is what is sent to the frontend, same information is accessible to the user.
        var result = equipment.serialize();
        
        expect(result).toBe("{\"T100_LEVEL\":\"0.6\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"0.06\", \"T400_LEVEL\":\"0.25\", \"V102\":\"0\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"true\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"true\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"216\", \"LI200\":\"90\", \"LI400\":\"90\", \"PI300\":\"120\", \"FI100\":\"0\", \"TI100\":\"20\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"0\", \"P200\":\"100\", \"E100\":\"false\"}");
    });
});
