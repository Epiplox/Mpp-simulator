// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const Equipment = require("../equipment");

// Tests the methods of the Equipment class.
describe("Equipment test UT:03", () => {
    const equipment = new Equipment();
    equipment.initializeActuators();

    test("initializeActuators()", () => {
        expect(typeof(equipment.actuators)).toBe("object");
        expect(typeof(equipment.actuators.get("T100"))).toBe("object");
        expect(equipment.actuators.size).toBe(24);
    }); 

    test("updateActuator()", () => {
        expect(() => equipment.updateActuator("P300", 0)).toThrow("Unknown actuator P300");
        expect(() => equipment.updateActuator("P100", "not a number")).toThrow("Wrong value for P100");
        equipment.updateActuator("V101", true);
        expect(equipment.getActuator("V101")).toBe(true);
    });    

    test("getActuator()", () => {
        expect(typeof(equipment.getActuator("V101"))).toBe("boolean");
        expect(typeof(equipment.getActuator("V102"))).toBe("number");
        expect(typeof(equipment.getActuator("E100"))).toBe("boolean");
        expect(typeof(equipment.getActuator("P100"))).toBe("number");
        expect(typeof(equipment.getActuator("P100_P200_PRESET"))).toBe("boolean");
        expect(() => equipment.getActuator("P300")).toThrow("Unknown actuator P300");
        expect(() => equipment.getActuator(300)).toThrow("Unknown actuator 300");
    });

    test("getIndicator()", () => {
        expect(typeof(equipment.getIndicator("LI100"))).toBe("number");
        expect(typeof(equipment.getIndicator("PI300"))).toBe("number");
        expect(typeof(equipment.getIndicator("TI100"))).toBe("number");
        expect(typeof(equipment.getIndicator("FI100"))).toBe("number");
        expect(() => equipment.getIndicator("P300")).toThrow("Unknown indicator P300");
        expect(() => equipment.getIndicator(300)).toThrow("Unknown indicator 300");
    });

    test("getSignal()", () => {
        expect(typeof(equipment.getSignal("LA_PLUS_100"))).toBe("boolean");
        expect(typeof(equipment.getSignal("LS_MINUS_200"))).toBe("boolean");
        expect(typeof(equipment.getSignal("LS_MINUS_300"))).toBe("boolean");
        expect(typeof(equipment.getSignal("LS_PLUS_300"))).toBe("boolean");
        expect(() => equipment.getSignal("P300")).toThrow("Unknown signal P300");
        expect(() => equipment.getSignal(300)).toThrow("Unknown signal 300");
    });
    
    test("serialize()", () => {
        expect(typeof(equipment.serialize())).toBe("string");
        expect(equipment.serialize()[0]).toBe("{");
        expect(equipment.serialize().slice(-1)).toBe("}");
        expect(equipment.serialize().split(":").length - 1).toBe(34);
    });

    test("runSimulation()", () => {
        const spy = jest.spyOn(equipment.simulation, "runSimulation");
        equipment.runSimulation();
        expect(spy).toHaveBeenCalledTimes(0);
        spy.mockClear();
    });

    test("reset()", () => {
        const spy = jest.spyOn(equipment, "initializeActuators");
        equipment.reset();
        expect(spy).toHaveBeenCalledTimes(1);
        spy.mockClear();
    });

    test("Randomized class test 1", () => {
        const equipment = new Equipment();
        equipment.initializeActuators();

        expect(equipment.getActuator("V203")).toBe(false);
        equipment.updateActuator("V102", 1);
        expect(() => equipment.getIndicator("FI300")).toThrow("Unknown indicator FI300");
        equipment.updateActuator("V304", true);
        equipment.updateActuator("V204", true);
        expect(equipment.getIndicator("LI100")).toBe(216);
        equipment.updateActuator("V104", 1);
        expect(typeof(equipment.getActuator("T300"))).toBe("object");
        equipment.updateActuator("V304", false);
        expect(equipment.serialize()).toBe("{\"T100_LEVEL\":\"0.6\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"0.06\", \"T400_LEVEL\":\"0.25\", \"V102\":\"1\", \"V104\":\"1\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"true\", \"V301\":\"false\", \"V302\":\"false\", \"V303\":\"false\", \"V304\":\"false\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"216\", \"LI200\":\"90\", \"LI400\":\"90\", \"PI300\":\"0\", \"FI100\":\"0\", \"TI100\":\"20\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"0\", \"P200\":\"0\", \"E100\":\"false\"}");
    });

    test("Randomized class test 2", () => {
        const equipment = new Equipment();
        equipment.initializeActuators();

        expect(equipment.getIndicator("LI200")).toBe(90);
        equipment.updateActuator("V404", true);
        expect(() => equipment.getIndicator("V404")).toThrow("Unknown indicator V404");
        equipment.updateActuator("V101", true);
        equipment.updateActuator("V201", false);
        equipment.reset();
        expect(() => equipment.getSignal("T300")).toThrow("Unknown signal T300");
        equipment.updateActuator("V303", true);
        expect(equipment.getActuator("V202")).toBe(false);
        equipment.updateActuator("V202", false);
        expect(equipment.serialize()).toBe("{\"T100_LEVEL\":\"0.6\", \"T200_LEVEL\":\"0.25\", \"T300_LEVEL\":\"0.06\", \"T400_LEVEL\":\"0.25\", \"V102\":\"0\", \"V104\":\"0\", \"V101\":\"false\", \"V103\":\"false\", \"V201\":\"false\", \"V202\":\"false\", \"V203\":\"false\", \"V204\":\"false\", \"V301\":\"false\", \"V302\":\"false\", \"V303\":\"true\", \"V304\":\"false\", \"V401\":\"false\", \"V402\":\"false\", \"V403\":\"false\", \"V404\":\"false\", \"LI100\":\"216\", \"LI200\":\"90\", \"LI400\":\"90\", \"PI300\":\"0\", \"FI100\":\"0\", \"TI100\":\"20\", \"TI300\":\"20\", \"LA_PLUS_100\":\"true\", \"LS_MINUS_200\":\"true\", \"LS_MINUS_300\":\"true\", \"LS_PLUS_300\":\"false\", \"P100\":\"0\", \"P200\":\"0\", \"E100\":\"false\"}");
    });
});
