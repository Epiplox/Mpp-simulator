// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const Tank = require("../Actuators/Tank");

// Tests the methods of the Tank class.
describe("Tank test UT:01", () => {
    
    test("getLevelPercent()", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        expect(tank.getLevelPercent()).toBe(0.6);
    });

    test("#simulateLiquid() flow in", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(4, 0, 20, false);
        expect(tank.volume).toBeCloseTo(6.606, 2);
    });

    test("#simulateLiquid() flow out", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(0, 3, 20, false);
        expect(tank.volume).toBeCloseTo(6.595, 2);
    });

    test("#simulateLiquid() flow in and out", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(7, 2, 20, false);
        expect(tank.volume).toBeCloseTo(6.608, 2);
        expect(tank.level).toBeCloseTo(216.272, 2);
    });

    test("#simulateLiquid() tank empty", () => {
        var tank = new Tank("T100", 0.001, null, null, true);
        tank.runSimulation(0, 20, 20, false);
        expect(tank.volume).toBe(0);
        expect(tank.level).toBe(0);
    });

    test("#simulateLiquid() tank full", () => {
        var tank = new Tank("T100", 0.999, null, null, true);
        tank.runSimulation(20, 0, 20, false);
        expect(tank.levelAlarm).toBe(false);
        expect(tank.volume).toBe(11);
        expect(tank.level).toBe(360);
    });

    test("#simulateLiquid() level min", () => {
        var tank = new Tank("T200", 0.0001, null, true, null);
        tank.runSimulation(20, 0, 20, false);
        expect(tank.levelMin).toBe(false);
    });

    test("#simulateTemperature() flow in 80 °C ", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(20, 0, 80, false);
        expect(tank.temperature).toBeCloseTo(22.866, 2);
    });

    test("#simulateTemperature() temperature over 80 °C", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(100, 0, 2000, false);
        expect(tank.temperature).toBe(80);
    });

    test("#simulateTemperature() heater on", () => {
        var tank = new Tank("T100", 0.001, null, null, true);
        tank.runSimulation(0, 0, 20, true);
        expect(tank.temperature).toBeCloseTo(41.666, 2);
    });

    test("#simulateTemperature() cooling", () => {
        var tank = new Tank("T100", 0.6, null, null, true);
        tank.runSimulation(20, 0, 80, false);

        // Run 100 cycle
        for (let i = 0; i < 100; i++) {
            tank.runSimulation(0, 0, 20, false);
        }

        expect(tank.temperature).toBeCloseTo(22.494, 2);
    }); 
});
