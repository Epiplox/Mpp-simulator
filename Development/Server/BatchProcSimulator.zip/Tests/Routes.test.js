// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const Routes = require("../routes");
const Equipment = require("../equipment");

// Tests the methods of the Routes function.
describe("Routes test UT:04", () => {

    const equipment = new Equipment();
    equipment.initializeActuators();
    var actuators = equipment.actuators;
    
    test("returnRoutes()", () => {
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);

        actuators.set("V101", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);
        actuators.set("V101", false);
    });

    test("T100FlowOutRoutes()", () => {
        actuators.set("V102", 100).set("P100", 100).set("P100_P200_PRESET", true);
        actuators.set("V403", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V203", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V304", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V103", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(3);

        actuators.set("V301", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(4);

        // Reset actuators
        actuators.set("V102", 0).set("P100", 0).set("P100_P200_PRESET", false);
        actuators.set("V403", false).set("V203", false).set("V304", false)
        .set("V103", false).set("V301", false);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);
    });

    test("T200FlowOutRoutes()", () => {
        actuators.set("V201", true).set("P200", 100).set("P100_P200_PRESET", true);
        actuators.set("V202", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V402", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V303", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V301", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(3);

        actuators.set("V103", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(4);

        // Reset actuators
        actuators.set("V201", false).set("P200", 0).set("P100_P200_PRESET", false);
        actuators.set("V202", false).set("V402", false).set("V303", false)
        .set("V301", false).set("V103", false);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);
    });

    test("T300FlowOutTopRoutes()", () => {
        actuators.set("V204", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V401", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);


        // Reset actuators
        actuators.set("V204", false).set("V401", false);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);
    });

    test("T300FlowOutBotRoutes()", () => {
        actuators.set("V302", true).set("P200", 100).set("P100_P200_PRESET", true);
        actuators.set("V402", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V303", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V103", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V301", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(3);

        // Reset actuators
        actuators.set("V302", false).set("P200", 0).set("P100_P200_PRESET", false);
        actuators.set("V402", false).set("V303", false).set("V103", false)
        .set("V301", false);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);
    });

    test("T400FlowOutRoutes()", () => {
        actuators.set("V404", true).set("P200", 100).set("P100_P200_PRESET", true);
        actuators.set("V402", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(1);

        actuators.set("V101", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V303", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(2);

        actuators.set("V103", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(3);

        actuators.set("V301", true);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(4);

        // Reset actuators
        actuators.set("V404", false).set("P200", 0).set("P100_P200_PRESET", false);
        actuators.set("V402", false).set("V101", false).set("V303", false)
        .set("V103", false).set("V301", false);
        var routes = new Routes(actuators);
        expect(routes.returnRoutes().length).toBe(0);
    });
    
    test("Outputs", () => {
        actuators.set("V101", true);
        actuators.set("V204", true);
        actuators.set("V404", true).set("P200", 100).set("P100_P200_PRESET", true).set("V402", true);
        actuators.set("V102", 100).set("P100", 100).set("P100_P200_PRESET", true).set("V403", true);
        var routes = new Routes(actuators);

        var allRoutes = routes.returnRoutes();
        expect(allRoutes.length).toBe(4);

        expect(allRoutes[0]).toStrictEqual(["T100", "T400", "P100"]);
        expect(allRoutes[1]).toStrictEqual(["T300T", "T200", "Vol"]);
        expect(allRoutes[2]).toStrictEqual(["T400", "T100", "Grav"]);
        expect(allRoutes[3]).toStrictEqual(["T400", "T400", "P200"]);
    });
});
