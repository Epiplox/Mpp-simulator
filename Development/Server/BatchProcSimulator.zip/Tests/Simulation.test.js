// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const Simulation = require("../Simulation");
const Equipment = require("../equipment");

// Tests the methods of the Simulation class.
describe("Simulation test UT:05", () => {
    var equipment = new Equipment();
    
    // Only tanks are affected
    test("Default state", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        var result = simulation.runSimulation(equipment.actuators);

        expect(result.get("T100")).toEqual({"flowIn": 0, "flowOut": 0, "level": 216, "levelAlarm": true, 
            "levelMax": null, "levelMin": null, "name": "T100", "temperature": 20, "volume": 6.6});
        expect(result.get("T200")).toEqual({"flowIn": 0, "flowOut": 0, "level": 90, "levelAlarm": null, 
            "levelMax": null, "levelMin": true, "name": "T200", "temperature": 20, "volume": 2.75});
        expect(result.get("T300")).toEqual({"flowIn": 0, "flowOut": 0, "levelMax": false, 
            "levelMin": true, "name": "T300", "pressure": 0, "temperature": 20, "volume": 0.12});
        expect(result.get("T400")).toEqual({"flowIn": 0, "flowOut": 0, "level": 90, "levelAlarm": null, 
            "levelMax": null, "levelMin": null, "name": "T400", "temperature": 20, "volume": 2.75});
    });

    test("T200 -> T300, P200, no pressure", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V201", true);
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V303", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("V401", true);
        var result = simulation.runSimulation(equipment.actuators);

        // T200
        expect(result.get("T200").flowIn).toBe(0);
        expect(result.get("T200").flowOut).toBe(4);
        expect(result.get("T200").level).toBeCloseTo(89.781, 2);
        expect(result.get("T200").volume).toBeCloseTo(2.743, 2);

        // T300
        expect(result.get("T300").flowIn).toBe(4);
        expect(result.get("T300").flowOut).toBe(0);
        expect(result.get("T300").pressure).toBe(0);
        expect(result.get("T300").volume).toBeCloseTo(0.126, 2);
    });
    
    test("T200 -> T300, P200, some pressure", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V201", true);
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V303", true);
        equipment.actuators.set("V301", true);
        var result = simulation.runSimulation(equipment.actuators);

        // T200
        expect(result.get("T200").flowIn).toBe(0);
        expect(result.get("T200").flowOut).toBe(4);
        expect(result.get("T200").level).toBeCloseTo(89.781, 2);
        expect(result.get("T200").volume).toBeCloseTo(2.743, 2);

        // T300
        expect(result.get("T300").flowIn).toBe(4);
        expect(result.get("T300").flowOut).toBe(0);
        expect(result.get("T300").pressure).toBe(0.12);
        expect(result.get("T300").volume).toBeCloseTo(0.126, 2); 
    });
    
    test("T400 -> T100, Grav", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V101", true);
        var result = simulation.runSimulation(equipment.actuators);

        // T400
        expect(result.get("T400").flowIn).toBe(0);
        expect(result.get("T400").flowOut).toBeCloseTo(6.074, 2);
        expect(result.get("T400").level).toBeCloseTo(89.668, 2);
        expect(result.get("T400").volume).toBeCloseTo(2.739, 2);

        // T100
        expect(result.get("T100").flowIn).toBeCloseTo(6.074, 2);
        expect(result.get("T100").flowOut).toBe(0);
        expect(result.get("T100").level).toBeCloseTo(216.331, 2);
        expect(result.get("T100").volume).toBeCloseTo(6.610, 2);
    });

    test("T100 -> T300, P100 with V102 at 99 %, no pressure", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 99);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("V204", true);
        var result = simulation.runSimulation(equipment.actuators);

        // T100
        expect(result.get("T100").flowIn).toBe(0);
        expect(result.get("T100").flowOut).toBe(3.96);
        expect(result.get("T100").level).toBeCloseTo(215.784, 2);
        expect(result.get("T100").volume).toBeCloseTo(6.593, 2);

        // T300
        expect(result.get("T300").flowIn).toBe(3.96);
        expect(result.get("T300").flowOut).toBe(0);
        expect(result.get("T300").pressure).toBe(0);
        expect(result.get("T300").volume).toBeCloseTo(0.126, 2);  
    });

    test("T100 -> T300, P100, T200 -> T300, P200 no pressure", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 100);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("V204", true);
        equipment.actuators.set("V201", true);
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("V303", true);
        var result = simulation.runSimulation(equipment.actuators);

        // T100
        expect(result.get("T100").flowIn).toBe(0);
        expect(result.get("T100").flowOut).toBe(4);
        expect(result.get("T100").level).toBeCloseTo(215.781, 2);
        expect(result.get("T100").volume).toBeCloseTo(6.593, 2);

        // T200
        expect(result.get("T200").flowIn).toBe(0);
        expect(result.get("T200").flowOut).toBe(4);
        expect(result.get("T200").level).toBeCloseTo(89.781, 2);
        expect(result.get("T200").volume).toBeCloseTo(2.743, 2);

        // T300
        expect(result.get("T300").flowIn).toBe(8);
        expect(result.get("T300").flowOut).toBe(0);
        expect(result.get("T300").pressure).toBe(0);
        expect(result.get("T300").volume).toBeCloseTo(0.133, 2);
    });

    test("T400 -> T300 -> T200, P200, 600 cycles to empty T400", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V404", true);
        equipment.actuators.set("P200", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V303", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("V204", true);
        var result = simulation.runSimulation(equipment.actuators);

        // Run 600 cycles
        for (let i = 0; i < 600; i++) {
            simulation = new Simulation();
            var result = simulation.runSimulation(result);
        }

        // T200
        expect(result.get("T200").flowIn).toBe(4);
        expect(result.get("T200").flowOut).toBe(0);
        expect(result.get("T200").level).toBeCloseTo(159.381, 2);
        expect(result.get("T200").volume).toBeCloseTo(4.870, 2);

        // T300
        expect(result.get("T300").flowIn).toBe(4);
        expect(result.get("T300").flowOut).toBe(4);
        expect(result.get("T300").pressure).toBe(0);
        expect(result.get("T300").volume).toBe(2);

        // T400
        expect(result.get("T400").flowIn).toBe(0);
        expect(result.get("T400").flowOut).toBe(4);
        expect(result.get("T400").level).toBe(0);
        expect(result.get("T400").volume).toBe(0);
    });

    test("T100 -> T300 -> T100, P100 with V104 60 % throttle", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 100);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V304", true);
        equipment.actuators.set("V301", true);
        equipment.actuators.set("V204", true);
        var result = simulation.runSimulation(equipment.actuators);

        // Run 400 cycles
        for (let i = 0; i < 400; i++) {
            simulation = new Simulation();
            var result = simulation.runSimulation(result);
        }
        
        result.set("V204", false);
        result.set("V104", 60);
        simulation = new Simulation();
        result = simulation.runSimulation(result);

        // T300
        expect(result.get("T300").flowIn).toBeCloseTo(2.337, 2);
        expect(result.get("T300").flowOut).toBeCloseTo(2.337, 2);
        expect(result.get("T300").pressure).toBeCloseTo(0.124, 2);
        expect(result.get("T300").volume).toBe(2);
    });

    test("1 pump to 2 tanks", () => {
        var simulation = new Simulation();
        equipment.initializeActuators();
        equipment.actuators.set("V102", 100);
        equipment.actuators.set("P100", 100);
        equipment.actuators.set("P100_P200_PRESET", true);
        equipment.actuators.set("V203", true);
        equipment.actuators.set("V403", true);
        var result = simulation.runSimulation(equipment.actuators);

        expect(result.get("T100").volume).toBeCloseTo(6.593, 2);
        expect(result.get("T400").volume).toBeCloseTo(2.753, 2);
        expect(result.get("T200").volume).toBeCloseTo(2.753, 2);

    });
});
