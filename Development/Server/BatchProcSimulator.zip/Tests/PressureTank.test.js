// Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 3/2025
// Modified: 3/2025

const PressureTank = require("../Actuators/PressureTank");

// Tests the methods of the PressureTank class.
describe("PressureTank test UT:02", () => {
    test("getLevelPercent()", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        expect(pressureTank.getLevelPercent()).toBe(0.06);
    });

    test("#simulatePressure() S1: Pressure escapes", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 4, 0, 20, true, 0, 0);
        expect(pressureTank.pressure).toBe(0);
    });

    test("#simulatePressure() S2: Some pressure because pump", () => {
        var pressureTank = new PressureTank("T300", 0.95);
        pressureTank.runSimulation(true, 0, 0, 20, false, 0, 0);
        expect(pressureTank.pressure).toBe(0.12);
        expect(pressureTank.getPressure()).toBe(120);
    });

    test("#simulatePressure() S3: Full pressure because pump and full throttling", () => {
        var pressureTank = new PressureTank("T300", 1);

        // Run 10 cycle
        for (let i = 0; i < 10; i++) {
            pressureTank.runSimulation(true, 0, 0, 20, false, 0, 1);
        }
        
        expect(pressureTank.pressure).toBe(0.29);
    });

    test("#simulatePressure() S4: Throttled flow", () => {
        var pressureTank = new PressureTank("T300", 1);
        pressureTank.runSimulation(true, 2.33766, 2.33766, 20, false, 60, 4/75);
        expect(pressureTank.pressure).toBeCloseTo(0.124);
    });

    test("#simulatePressure() S5: Existing pressure stays", () => {
        var pressureTank = new PressureTank("T300", 0.95);
        pressureTank.runSimulation(false, 0, 0, 20, false, 0, 0);
        expect(pressureTank.pressure).toBeCloseTo(0);
    });

    test("#simulatePressure() S6: Pressure espaces from throttle valve", () => {
        var pressureTank = new PressureTank("T300", 1);
        pressureTank.runSimulation(false, 0, 0, 20, false, 100, 0);
        expect(pressureTank.pressure).toBeCloseTo(0);
    });

    test("#simulateLiquid() flow in", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 4, 0, 20, true, 0, 0);
        expect(pressureTank.volume).toBeCloseTo(0.126, 2);
    });

    test("#simulateLiquid() flow out", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 0, 4, 20, true, 0, 0);
        expect(pressureTank.volume).toBeCloseTo(0.113, 2);
    });

    test("#simulateLiquid() flow in and out", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 4, 7, 20, true, 0, 0);
        expect(pressureTank.volume).toBeCloseTo(0.114, 2);
    });

    test("#simulateLiquid() tank empty", () => {
        var pressureTank = new PressureTank("T300", 0.006);
        pressureTank.runSimulation(true, 0, 20, 20, true, 0, 0);
        expect(pressureTank.volume).toBe(0);
        expect(pressureTank.levelMin).toBe(false);
    });

    test("#simulateLiquid() tank full", () => {
        var pressureTank = new PressureTank("T300", 0.99);
        pressureTank.runSimulation(true, 20, 0, 20, true, 0, 0);
        expect(pressureTank.volume).toBe(2);
        expect(pressureTank.levelMax).toBe(true);
    });

    test("#simulateTemperature() flow in 80 °C ", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 20, 0, 80, true, 0, 0);
        expect(pressureTank.temperature).toBeCloseTo(61.038, 2);
    });

    test("#simulateTemperature() temperature over 80 °C", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 200, 0, 1000, true, 0, 0);
        expect(pressureTank.temperature).toBe(80);
    });

    test("#simulateTemperature() cooling", () => {
        var pressureTank = new PressureTank("T300", 0.06);
        pressureTank.runSimulation(true, 20, 0, 80, true, 0, 0);

        // Run 100 cycle
        for (let i = 0; i < 100; i++) {
            pressureTank.runSimulation(false, 0, 0, 20, true, 0, 0);
        }

        expect(pressureTank.temperature).toBeCloseTo(55.713, 2);
    });
});
