// Petri Kannisto, Eero Eriksson
// TTI/AUT
// Tampere University
// Created: 7/2017
// Modified: 3/2025

/**
 * The OPC UA server
 */

// Creating a Simple Server
// The MIT License (MIT)
// Copyright (c) 2022-2024  Sterfive SAS - 833264583 RCS ORLEANS - France (https://www.sterfive.com)
// https://github.com/node-opcua/node-opcua/blob/master/documentation/sample_server.js
// https://github.com/node-opcua/node-opcua/blob/master/documentation/creating_a_server.md

const opcuaModule = require("node-opcua");
const StatusCodes = require("node-opcua-status-code").StatusCodes;
const Equipment = require("./Equipment");

/**
 * Implements an OPC UA server for the equipment.
 */
function UaServer(equipment)
{
	var UA_SERVER_URN = "urn:CX-19788E:BeckhoffAutomation:TcOpcUaServer:1";
	var UA_PLC1_URN = "urn:CX-19788E:BeckhoffAutomation:Ua:PLC1";
	
	var self = this;   
    var addressSpace;
    var plc1Namespace;
	
    // Creates the OPC UA server
	var opcUaServer = new opcuaModule.OPCUAServer({
        hostname: "127.0.0.1",
	    port: 8087, // the port of the listening socket of the server
	    resourcePath: "", // this path will be added to the endpoint resource name
	    buildInfo : {
	        productName: "BatchSimulationServer",
	        buildNumber: "2",
	        buildDate: new Date(2025, 3, 5)
	    },
	    serverInfo : {
	    	applicationUri: UA_SERVER_URN // This will appear as the default namespace
	    },
	});

	/**
     * Adds the simple devices (Datatype: Boolean) to the PLC1 namespace. 
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     */
	this.addUaSimpleDevice = function(parent, name)
	{
        var value =
        {
            get: function ()
            {
            	return new opcuaModule.Variant({dataType: opcuaModule.DataType.Boolean, value: equipment.getActuator(name)});
            },
    		set: function (variantIn)
    		{
    			equipment.updateActuator(name, variantIn.value);
                return StatusCodes.Good;
            }
        };

        this.addUaVariable(parent, name, "Boolean", value);
	};

    /**
     * Adds the proportional devices (Datatype: UInt16) to the PLC1 namespace.
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     */
	this.addUaProportionalDevice = function(parent, name)
	{
        var value =
        {
            get: function ()
            {
            	return new opcuaModule.Variant({dataType: opcuaModule.DataType.UInt16, value: equipment.getActuator(name)});
            },
    		set: function (variantIn)
    		{
    			equipment.updateActuator(name, variantIn.value);
                return StatusCodes.Good;
            }
        };
        
        this.addUaVariable(parent, name, "UInt16", value);
	};

    /**
     * Adds the integer indicator (Datatype: UInt16) to the PLC1 namespace.
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     */
	this.addUaIntegerIndicator = function(parent, name)
	{
        var value =
        {
            get: function ()
            {
            	var retValue = equipment.getIndicator(name);
            	return new opcuaModule.Variant({dataType: opcuaModule.DataType.UInt16, value: retValue });
            }
        };
        
        this.addUaVariable(parent, name, "UInt16", value);
	};

    /**
     * Adds the float indicator (Datatype: Double) to the PLC1 namespace.
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     */
	this.addUaFloatIndicator = function(parent, name)
	{
        var value = 
        {
            get: function ()
            {
            	var retValue = equipment.getIndicator(name);
            	return new opcuaModule.Variant({dataType: opcuaModule.DataType.Double, value: retValue });
            }
        };
		
        this.addUaVariable(parent, name, "Double", value);
	};

    /**
     * Adds the signal (Datatype: Boolean) to the PLC1 namespace.
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     */
	this.addUaSignal = function(parent, name)
	{
		var value = {
            get: function ()
            {
            	var retValue = equipment.getSignal(name);
            	return new opcuaModule.Variant({dataType: opcuaModule.DataType.Boolean, value: retValue });
            }
        };
		
		this.addUaVariable(parent, name, "Boolean", value);
	};

    /**
     * Adds the devices to the server with needed parameters.
     * @param {opcuaModule.UAObject} parent Object to store the variable
     * @param {string} name Name of the actuator
     * @param {string} dataType Datatype that the actuator uses
     * @param {*} value Get and Set functions of the actuator
     */
	this.addUaVariable = function(parent, name, dataType, value)
	{
		var namespaceIndex = addressSpace.getNamespaceIndex(UA_PLC1_URN);
		var displayName = "EQ_" + name;
		var nodeId = self.createNodeIdSerializedString(namespaceIndex, "eq_states." + displayName);

		plc1Namespace.addVariable({
            componentOf: parent,
            browseName: displayName,
            displayName: displayName,
            dataType: dataType,
            nodeId: nodeId,
            typeDefinition: "DataItemType",
            value: value,
            minimumSamplingInterval: 1000
        });
	};
	
    /**
     * Creates a string of Nodeid for the namespaces and devices.
     * @param {number} namespaceIndex Index number of the namespace
     * @param {string} browseName Name of the namespace
     * @returns {string} Nodeid as a string
     */
	this.createNodeIdSerializedString = function(namespaceIndex, browseName)
	{
		// Integer node ID: "ns=0;i=62"
		// String node ID: "ns=0;s=foo"
		return "ns=" + namespaceIndex + ";s=" + browseName;
	};

    /**
     * Setups the namespaces and devices to the OPC UA server.
     */
	this.postInitialize = function()
	{
	    console.log("OPC UA server initialized");
	    
    	addressSpace = opcUaServer.engine.addressSpace;
        
        // Registering PLC1 namespace
        plc1Namespace = addressSpace.registerNamespace(UA_PLC1_URN);

        // Declaring PLC1
        var plc1Name = "PLC1";
        var plc1 = addressSpace.getOwnNamespace().addObject({
            organizedBy: addressSpace.rootFolder.objects,
            browseName: plc1Name,
            nodeId: self.createNodeIdSerializedString(addressSpace.getNamespaceIndex(UA_SERVER_URN), plc1Name),
            displayName: plc1Name
        });
        
        // Declaring process parts
        var eqStatesName = "eq_states";
        var eqStates = plc1Namespace.addObject({
        	componentOf: plc1,
    	    browseName: eqStatesName,
    	    displayName: eqStatesName,
    	    nodeId: self.createNodeIdSerializedString(plc1Namespace.index, eqStatesName),
    	    typeDefinition: "FolderType",
    	});

        // Declaring actuators
        
        // On/off valves
        self.addUaSimpleDevice(eqStates, "V101");
        self.addUaSimpleDevice(eqStates, "V103");
        self.addUaSimpleDevice(eqStates, "V201");
        self.addUaSimpleDevice(eqStates, "V202");
        self.addUaSimpleDevice(eqStates, "V203");
        self.addUaSimpleDevice(eqStates, "V204");
        self.addUaSimpleDevice(eqStates, "V301");
        self.addUaSimpleDevice(eqStates, "V302");
        self.addUaSimpleDevice(eqStates, "V303");
        self.addUaSimpleDevice(eqStates, "V304");
        self.addUaSimpleDevice(eqStates, "V401");
        self.addUaSimpleDevice(eqStates, "V402");
        self.addUaSimpleDevice(eqStates, "V403");
        self.addUaSimpleDevice(eqStates, "V404");

        // Control valves
        self.addUaProportionalDevice(eqStates, "V102");
        self.addUaProportionalDevice(eqStates, "V104");

        // Heater
        self.addUaSimpleDevice(eqStates, "E100");

        // Pumps and preset
        self.addUaProportionalDevice(eqStates, "P100");
        self.addUaProportionalDevice(eqStates, "P200");
        self.addUaSimpleDevice(eqStates, "P100_P200_PRESET");

        // Indicators
        self.addUaIntegerIndicator(eqStates, "LI100");
        self.addUaIntegerIndicator(eqStates, "LI200");
        self.addUaIntegerIndicator(eqStates, "LI400");
        self.addUaIntegerIndicator(eqStates, "PI300");
        self.addUaFloatIndicator(eqStates, "TI100");
        self.addUaFloatIndicator(eqStates, "TI300");
        self.addUaFloatIndicator(eqStates, "FI100");
        
        // Declaring signals
        self.addUaSignal(eqStates, "LA_PLUS_100");
        self.addUaSignal(eqStates, "LS_MINUS_200");
        self.addUaSignal(eqStates, "LS_MINUS_300");
        self.addUaSignal(eqStates, "LS_PLUS_300");
        
        // Starts the server
	    opcUaServer.start();
        console.log("OPC UA server is now listening...");
        console.log("OPC UA server port is ", opcUaServer.endpoints[0].port);
        var endpointUrl = opcUaServer.endpoints[0].endpointDescriptions()[0].endpointUrl;
        console.log("OPC UA server: the primary server endpoint url is ", endpointUrl);
	};

	opcUaServer.initialize(this.postInitialize);
}

module.exports = UaServer;
