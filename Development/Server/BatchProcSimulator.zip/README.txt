----- VERSIONS -----

VSCode, 1.98.2
Node.js, 27.9.0
Express, 4.21.2
Express-sse, 0.5.3
Jest, 29.7.0
Node-opcua, 2.148.0

----- DOCUMENTATION -----

Test Documentation
System Documentation

----- USER GUIDE -----

Download the files and open a terminal in the main folder. Type "node app.js" and run the simulator.
The user interface is visible in http://127.0.0.1:8088/ on a web browser after running the simulator.
There should be no need for additional set up.